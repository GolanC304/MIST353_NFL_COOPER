#!/bin/bash
cd /home/site/wwwroot/API
gunicorn -w 4 -k uvicorn.workers.UvicornWorker nfl_playoffs_api:app